Aufgabe 1: Run bash-file ./Scripts/ALU/simulate.sh
Aufgabe 2: Run bash-file ./Scripts/Register/PipelineRegBash.sh
Aufgabe 3: Run bash-file ./Scripts/Multiplexer/gen_muxBash.sh