Versuch 7
Task 1:

    bash Scripts\ALU\simulate.sh

Task 2,3:

    bash Scripts\RISCV\RIUB_only_RISC_V_tb.sh

