Aufgabe 1:
    

Aufgabe 2:
    Im Terminal: Geben Sie bash Scripts/SignExtender/signExtention.sh ein.
