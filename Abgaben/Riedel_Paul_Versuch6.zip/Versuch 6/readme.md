Verscuh 6

execute: 

bash Scripts/RISCV/RIU_only_RISC_V_tb.sh