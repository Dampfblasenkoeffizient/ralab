-- Laboratory RA solutions/versuch8
-- Sommersemester 25
-- Group Details
-- Lab Date: 25.06.2025
-- 1. Participant First and Last Name: Clara Heilig
-- 2. Participant First and Last Name: Paul Riedel

Task 1:

	bash Scripts/Decoder/decoder_tb.sh
    bash Scripts/RISCV/RIUBS_only_RISC_V_tb.sh