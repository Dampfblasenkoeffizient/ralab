Versuch 5:
    run: bash Scripts/RISCV/R_only_RISC_V_tb.sh