Aufgabe 1: Run bash-file ./Scripts/RAM/sim_SP_RAM.sh
Aufgabe 2: Run bash-file ./Scripts/Registerfile/register_file_tb.sh