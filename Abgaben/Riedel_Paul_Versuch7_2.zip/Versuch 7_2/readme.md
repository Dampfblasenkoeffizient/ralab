Versuch 7_2
Task 1:

    bash Scripts\RISCV\RIUB_only_RISC_V_tb.sh