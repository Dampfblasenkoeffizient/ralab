Task 1: bash ./Scripts/ALU/simulate.sh
Task 2: bash ./Scripts/Decoder/decoder_tb.sh
Task 3: bash ./Scripts/Registerfile/register_file_tb.h
Task 4: bash ./Scripts/RISCV/RI_only_RISC_V_tb.sh
